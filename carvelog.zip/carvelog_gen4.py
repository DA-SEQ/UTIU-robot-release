#!/usr/bin/env python3
"""
Refactored Unified Multi-Pass Clustering + Classification
- TF-IDF multi-pass (vocab, docfreq, full matrix) in streaming
- Automatic k selection via silhouette
- Two-tier classification (RF fallback to k-means)
- Meta-features (distance, softmax probability)
- Feature selection for classifier
- Persistent multiprocessing Pool
- TQDM progress bars on ogni fase CPU-intensive
- Estrazione e stampa di N esempi per cluster
- Modello persistito con joblib + metadata
"""
import sys
import os
import math
import yaml
import random
import logging
import multiprocessing
import numpy as np
from collections import defaultdict, Counter
from typing import List, Dict, Tuple
from tqdm import tqdm
from scipy.sparse import coo_matrix, csr_matrix, vstack, hstack
from sklearn.cluster import MiniBatchKMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import silhouette_score, silhouette_samples, calinski_harabasz_score, davies_bouldin_score

from sklearn.feature_selection import SelectKBest, chi2
from joblib import dump

import warnings; warnings.filterwarnings("ignore", message="Clustering metrics expects")
# ------------------------------------------------
# Logging config
# ------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)

# ------------------------------------------------
# Utility: file streaming, TF-IDF workers, ngrams
# ------------------------------------------------
def load_config(path: str) -> dict:
    if not os.path.exists(path):
        logging.error(f"Config file '{path}' not found.")
        sys.exit(1)
    with open(path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)



def stream_log_file(file_path: str, chunk_size: int) -> List[str]:
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        buf = []
        for line in f:
            ln = line.strip()
            if not ln:
                continue
            buf.append(ln)
            if len(buf) >= chunk_size:
                yield buf
                buf = []
        if buf:
            yield buf


def count_nonempty_lines(file_path: str) -> int:
    c = 0
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if line.strip():
                c += 1
    return c


# ───────────────────────────── N-GRAMS ──────────────────────────────
def collect_word_ngrams_single_line(line: str, ng_cfg) -> set:
    t = line.split()
    s = set()

    # word n-grams (variable length)
    for n in range(ng_cfg["word_min"], ng_cfg["word_max"] + 1):
        for i in range(len(t) - n + 1):
            s.add(" ".join(t[i : i + n]))

    # skip-grams
    if ng_cfg["use_skip_grams"]:
        max_skip = ng_cfg["max_skip_size"]
        for i in range(len(t)):
            for j in range(i + 1, min(len(t), i + max_skip + 2)):
                s.add(t[i] + " _ " + t[j])

    # positional marks
    if ng_cfg["mark_position"] and t:
        s.add("^" + t[0])        # start token
        s.add(t[-1] + "$")       # end token
    return s


def collect_char_ngrams_single_line(line: str, ng_cfg) -> set:
    s, L = set(), len(line)
    for n in range(ng_cfg["char_min"], ng_cfg["char_max"] + 1):
        for i in range(L - n + 1):
            s.add(line[i : i + n])
    return s


def ngram_extractor(line: str, ng_cfg) -> set:
    return (
        collect_word_ngrams_single_line(line, ng_cfg)
        | collect_char_ngrams_single_line(line, ng_cfg)
    )


def worker_transform(args):
    line, token2idx, idf_array, ng_cfg, sublinear_tf = args
    tf = defaultdict(int)
    for ng in ngram_extractor(line, ng_cfg):
        idx = token2idx.get(ng)
        if idx is not None:
            tf[idx] += 1
    rows, cols, data = [], [], []
    for idx_, cnt in tf.items():
        sub = 1 + math.log(cnt) if sublinear_tf else float(cnt)
        val = sub * idf_array[idx_]
        if val != 0:
            rows.append(0)
            cols.append(idx_)
            data.append(val)
    return rows, cols, data


def transform_chunk(
    lines: List[str],
    token2idx: Dict[str, int],
    idf_array: np.ndarray,
    pool: multiprocessing.Pool,
    n_procs: int,
    ng_cfg: dict,
    sublinear_tf: bool,
) -> csr_matrix:
    """
    Converte un blocco di linee in matrice TF-IDF (float64).
    """
    tasks = [(ln, token2idx, idf_array, ng_cfg, sublinear_tf) for ln in lines]
    results = pool.imap(worker_transform, tasks)

    rows, cols, data = [], [], []
    for i, (r, c, d) in enumerate(results):
        rows.extend([i] * len(r))
        cols.extend(c)
        data.extend(d)

    mat = coo_matrix(
        (data, (rows, cols)),
        shape=(len(lines), len(token2idx)),
        dtype=np.float64,  # float64 per compatibilità scikit-learn
    ).tocsr()

    return mat


def worker_docfreq(args):
    line, vocab, ng_cfg = args
    seen = set()
    out = {}

    tokens = line.split()
    # word n-grams / skip-grams / pos marks
    for tok in collect_word_ngrams_single_line(line, ng_cfg):
        if tok in vocab:
            seen.add(tok)
    # char n-grams
    for tok in collect_char_ngrams_single_line(line, ng_cfg):
        if tok in vocab:
            seen.add(tok)

    for t in seen:
        out[t] = 1

    return out


# ------------------------------------------------
# MultiPassFlow
# ------------------------------------------------
class MultiPassFlow:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.file_path = cfg["training_dataset"]
        self.chunk_size = cfg.get("chunk_size", 50000)
        self.n_procs = cfg.get("n_processes", multiprocessing.cpu_count())
        self.pool = multiprocessing.Pool(self.n_procs)

        kr = cfg.get("initial_k_range", [2, 5])
        self.k_values = list(range(kr[0], kr[1] + 1))
        self.expand = cfg.get("expand_k_if_best_is_max", False)
        self.step = cfg.get("expand_step", 5)
        self.max_exp = cfg.get("max_expansions", 1)

        self.conf_th = cfg.get("confidence_threshold", 0.8)
        self.samples_per_cluster = cfg.get("max_samples_per_cluster", 5)

        self.vocab = {}
        self.idf = None
        self.token2idx = {}
        self.best_k = None
        self.km = None
        self.clf = None
        self.sel_mask = None

        self.ng_cfg = self.cfg.get("ngram", {})
        self.sublinear_tf = self.cfg.get("sublinear_tf", True)

    # -------------------- FLOW ENTRY --------------------
    def run(self):
        logging.info("[MultiPass] Avvio...")
        self._phase1_vocab()
        self._phase2_df_idf()
        self._phase3_tfidf_and_select_k()
        self._phase4_partial_fit()
        samples, labels = self._phase5_gather_samples()

        cluster_map = self._phase7_collect_examples()
        self._get_top_ngrams_per_cluster()
        self._phase8_print_examples(cluster_map)
        self._phase6_train_classifier(samples, labels)
        self._phase9_save()
        logging.info("[MultiPass] Flow completo.")

    # -------------------- PHASE 1 -----------------------
    def _phase1_vocab(self):
        logging.info("Fase1: vocab-building")
        total = count_nonempty_lines(self.file_path)
        vocab_set = set()
        pbar = tqdm(total=total, desc="vocab-multipass", unit="line")
        for chunk in stream_log_file(self.file_path, self.chunk_size):
            results = self.pool.starmap(
                ngram_extractor, [(ln, self.ng_cfg) for ln in chunk]
            )
            for s in results:
                vocab_set |= s
            pbar.update(len(chunk))
        pbar.close()
        self.vocab = {tok: i for i, tok in enumerate(vocab_set)}
        self.token2idx = self.vocab
        logging.info(f"Vocab size={len(self.vocab)}")

    # -------------------- PHASE 2 -----------------------
    def _phase2_df_idf(self):
        """
        Fase 2 – Calcolo DF e IDF:
        • niente lambda (picklable)
        • IDF array in float64
        """
        logging.info("Fase2: compute docfreq + idf")

        total_lines = count_nonempty_lines(self.file_path)
        df_counter = defaultdict(int)
        pbar = tqdm(total=total_lines, desc="doc-freq", unit="line")

        for chunk in stream_log_file(self.file_path, self.chunk_size):
            tasks = [(line, self.vocab, self.ng_cfg) for line in chunk]
            partial_results = self.pool.map(worker_docfreq, tasks)
            for token_dict in partial_results:
                for tok in token_dict:
                    df_counter[tok] += 1
            pbar.update(len(chunk))

        pbar.close()

        # ----- IDF in float64 -----
        N = total_lines
        self.idf = np.zeros(len(self.vocab), dtype=np.float64)
        filtered = 0
        min_df = self.cfg.get("min_df", 1)
        max_df_ratio = self.cfg.get("max_df_ratio", 1.0)
        for tok, idx in self.token2idx.items():
            df = df_counter.get(tok, 0)
            if df < min_df or df > max_df_ratio * N:
                # mark for deletion
                self.idf[idx] = 0.0
                filtered += 1
            else:
                self.idf[idx] = math.log(float(N) / (1 + df)) + 1.0
        logging.info(f"Token filtered by df: {filtered:,}")
        logging.info("IDF calcolato.")

    # -------------------- PHASE 3 -----------------------
    def _phase3_tfidf_and_select_k(self):
        logging.info("Fase3: build full TF-IDF + select k")
        X_blocks = []
        total = count_nonempty_lines(self.file_path)
        pbar = tqdm(total=total, desc="build-TFIDF", unit="line")
        for chunk in stream_log_file(self.file_path, self.chunk_size):
            Xb = transform_chunk(
                chunk,
                self.token2idx,
                self.idf,
                self.pool,
                self.n_procs,
                self.ng_cfg,
                self.sublinear_tf,
            )
            X_blocks.append(Xb)
            pbar.update(len(chunk))
        pbar.close()
        X_full = vstack(X_blocks).tocsr()
        self.X_full = X_full

        best_sil = -1
        best_k = None
        expansions = 0
        while True:
            for k in self.k_values:
                logging.info(f" Testing k={k}")
                km = MiniBatchKMeans(
                    n_clusters=k, batch_size=self.chunk_size, random_state=42
                )
                km.fit(X_full)
                labs = km.predict(X_full)
                try:
                    sil = silhouette_score(X_full, labs)
                    if self.cfg.get("silhouette_per_cluster", False):
                        from sklearn.metrics import silhouette_samples
                        ss = silhouette_samples(X_full, labs)
                        per = [
                            (c, float(np.mean(ss[labs == c])))
                            for c in range(k)
                        ]
                        logging.info(
                            "   per-cluster silhouette: "
                            + ", ".join(f"C{c}:{s:.2f}" for c, s in per)
                        )
                except Exception:
                    sil = -1
                logging.info(f"  silhouette={sil:.4f}")
                if sil > best_sil:
                    best_sil, best_k, self.km = sil, k, km
            if self.expand and best_k == self.k_values[-1] and expansions < self.max_exp:
                self.k_values = list(
                    range(self.k_values[0], self.k_values[-1] + self.step + 1)
                )
                expansions += 1
                continue
            break
        self.best_k = best_k
        logging.info(f"Best k={best_k}, silhouette={best_sil:.4f}")

    # -------------------- PHASE 4 -----------------------
    def _phase4_partial_fit(self):
        logging.info(f"Fase4: partial_fit final K={self.best_k}")
        total = count_nonempty_lines(self.file_path)
        pbar = tqdm(total=total, desc="final-partial-fit", unit="line")
        self.km = MiniBatchKMeans(
            n_clusters=self.best_k, batch_size=self.chunk_size, random_state=42
        )
        for chunk in stream_log_file(self.file_path, self.chunk_size):
            Xb = transform_chunk(
                chunk,
                self.token2idx,
                self.idf,
                self.pool,
                self.n_procs,
                self.ng_cfg,
                self.sublinear_tf,
            )
            self.km.partial_fit(Xb)
            pbar.update(len(chunk))
        pbar.close()

    # -------------------- PHASE 5 -----------------------
    def _phase5_gather_samples(self):
        logging.info("Fase5: gathering samples per classifier")
        samples, labs = [], []
        total = count_nonempty_lines(self.file_path)
        pbar = tqdm(total=total, desc="gather-samples", unit="line")
        for chunk in stream_log_file(self.file_path, self.chunk_size):
            Xb = transform_chunk(
                chunk,
                self.token2idx,
                self.idf,
                self.pool,
                self.n_procs,
                self.ng_cfg,
                self.sublinear_tf,
            )
            preds = self.km.predict(Xb)
            for line, cl in zip(chunk, preds):
                if random.random() < self.cfg.get("classifier_sample_rate", 0.01):
                    samples.append(line)
                    labs.append(cl)
            pbar.update(len(chunk))
        pbar.close()
        logging.info(f"Samples collected={len(samples)}")
        return samples, labs

    # -------------------- PHASE 6 -----------------------
    def _phase6_train_classifier(self, samples, labels):
        if not samples:
            logging.warning("No samples for classifier, skipping RF")
            return

        logging.info("Fase6: training RandomForest")

        # --- Feature matrix ---
        Xb = transform_chunk(
            samples,
            self.token2idx,
            self.idf,
            self.pool,
            self.n_procs,
            self.ng_cfg,
            self.sublinear_tf,
        )

        dist, prob = self._compute_meta(Xb)
        meta = csr_matrix(np.column_stack((dist, prob)), dtype=np.float64)
        Xc = hstack([Xb, meta])

        fs_cfg = self.cfg.get("feature_selection", {})
        if fs_cfg.get("kbest_score_func", "chi2") == "mutual_info":
            from sklearn.feature_selection import mutual_info_classif
            score_func = mutual_info_classif
        else:
            score_func = chi2
        selector = SelectKBest(
            score_func, k=min(fs_cfg.get("kbest_k", 1000), Xc.shape[1])
        )
        Xs = selector.fit_transform(Xc, labels)
        self.sel_mask = selector.get_support()
        cur_X = Xs

        rf_params = self.cfg.get("random_forest_params") or {}
        rf = RandomForestClassifier(**rf_params)

        # --- RF params & grid ---
        grid = self.cfg.get("random_forest_grid") or {
            "n_estimators": [rf_params.get("n_estimators", 50)],
            "max_depth": [rf_params.get("max_depth", None)],
        }
        grid = {
            **{"n_estimators": [rf_params.get("n_estimators", 50)],
               "max_depth": [rf_params.get("max_depth", None)]},
            **grid,
        }

        # --- choose CV splitter (stratified when possible) -----------------
        # -------------------------------------------------------------------
        # choose CV splitter (stratified when possible, safe n_splits)
        # -------------------------------------------------------------------
        cv_folds_cfg = self.cfg.get("cv_folds", 3)
        n_samples     = len(labels)
        if n_samples < 2:
            logging.warning("≤ 1 sample available — skipping classifier training.")
            return            # nothing sensible to do

        n_splits = min(cv_folds_cfg, n_samples)   # never > n_samples

        from collections import Counter
        min_class = min(Counter(labels).values())

        if min_class < n_splits:
            logging.warning(
                f"Some classes have < {n_splits} samples – "
                "using plain KFold instead of StratifiedKFold."
            )
            from sklearn.model_selection import KFold
            cv = KFold(n_splits=n_splits, shuffle=True, random_state=42)
        else:
            from sklearn.model_selection import StratifiedKFold
            cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)


        gs = GridSearchCV(
            rf,
            grid,
            cv=cv,
            verbose=1,
            n_jobs=self.n_procs,
            scoring="f1_weighted",
        )
        gs.fit(Xs, labels)

        # ----- Optional RFE ------------------------------------------------
        if fs_cfg.get("use_rfe", False):
            from sklearn.feature_selection import RFE
            step = fs_cfg.get("rfe_step", 0.1)

            # 1) run RFE on the K-best matrix
            rfe = RFE(rf, step=step, n_features_to_select=None)
            Xr = rfe.fit_transform(Xs, labels)
            cur_X = Xr

            # 2) rebuild a *full-length* mask
            rfe_support = rfe.get_support()               # len = Xs.shape[1]
            full_mask = np.zeros_like(self.sel_mask,      # len = Xc.shape[1]
                              dtype=bool)
            full_mask[self.sel_mask] = rfe_support        # insert RFE result
            self.sel_mask = full_mask                     # <- final mask

            # 3) refit RF on the RFE-reduced matrix
            rf.fit(Xr, labels)
        else:
            # no RFE: keep the SelectKBest mask
            rf.fit(Xs, labels)


        # ----- Drop features with low importance ---------------------------
        thr = fs_cfg.get("importance_threshold", 0.0)
        try:
            thr = float(thr)
        except (TypeError, ValueError):
            thr = 0.0

        if thr > 0 and cur_X.shape[1] > 1:   # skip if already ≤1 feature
            imp  = rf.feature_importances_
            keep = imp >= thr                # mask on the *current* subset

            n_keep = keep.sum()
            if n_keep == 0:                  # would kill every feature
                logging.warning(
                    "All features would be dropped by importance_threshold "
                    f"({thr}); skipping this filter."
                )
            elif n_keep == cur_X.shape[1]:   # nothing to drop
                logging.info("No feature below importance threshold.")
            else:
                # shrink matrix and rebuild full-length mask
                cur_X = cur_X[:, keep]
                full_mask = self.sel_mask.copy()
                full_mask[self.sel_mask] = keep
                self.sel_mask = full_mask

                rf.fit(cur_X, labels)        # re-fit on reduced set
                logging.info(f"Dropped {cur_X.shape[1] - n_keep} low-importance features.")
        self.clf = rf


    # Add this method to your MultiPassFlow class
    def _get_top_ngrams_per_cluster(self, n_terms: int = 10):
        logging.info("Top n-grams per cluster:")
        # Create a reverse mapping from index to token
        idx2token = {i: t for t, i in self.token2idx.items()}
    
        # Get the cluster centroids
        order_centroids = self.km.cluster_centers_.argsort()[:, ::-1]

        for i in range(self.best_k):
            top_for_cluster = [
                idx2token[ind] for ind in order_centroids[i, :n_terms]
            ]
            print(f"[Cluster {i}] Top terms: {', '.join(top_for_cluster)}")

    # Add this new method to your MultiPassFlow class
    def _calculate_cluster_quality(self) -> Dict[int, float]:
        """
        Calculates a unified Quality Score (0-1) for each cluster.
        This score is a weighted average of normalized cohesion, separation,
        silhouette, and Davies-Bouldin scores. Higher is better.
        """
        from sklearn.metrics import pairwise_distances
        import numpy as np
    
        # --- 1. Get Raw Data and Predictions ---
        X = self.X_full
        labs = self.km.labels_
        centroids = self.km.cluster_centers_
        K = self.best_k
    
        # --- 2. Calculate Raw Metrics for Each Cluster ---
        raw_sils, raw_cohesions, raw_seps, raw_dbs = [], [], [], []
        
        # Pre-calculate expensive metrics
        samp_sil = silhouette_samples(X, labs)
        centroid_dists = pairwise_distances(centroids)
        
        for i in range(K):
            # --- Silhouette ---
            cluster_mask = (labs == i)
            raw_sils.append(np.mean(samp_sil[cluster_mask]) if cluster_mask.any() else 0)
    
            # --- Cohesion ---
            cluster_points = X[cluster_mask]
            dist_to_centroid = pairwise_distances(cluster_points, centroids[i].reshape(1, -1))
            raw_cohesions.append(np.mean(dist_to_centroid) if cluster_mask.any() else np.inf)
    
            # --- Separation ---
            # Distance to the nearest other cluster centroid
            dists_to_others = np.delete(centroid_dists[i], i)
            raw_seps.append(np.min(dists_to_others) if len(dists_to_others) > 0 else 0)
            
            # --- Davies-Bouldin (per-cluster contribution) ---
            db_val = 0
            if cluster_mask.any():
                s_i = np.mean(pairwise_distances(cluster_points, centroids[i].reshape(1, -1)))
                ratios = []
                for j in range(K):
                    if i == j: continue
                    s_j = np.mean(pairwise_distances(X[labs == j], centroids[j].reshape(1, -1)))
                    if centroid_dists[i, j] > 0:
                        ratios.append((s_i + s_j) / centroid_dists[i, j])
                db_val = max(ratios) if ratios else 0
            raw_dbs.append(db_val)
            
        # --- 3. Normalize All Metrics to [0, 1] range ---
        # Note: For metrics where 'lower is better', we subtract from 1 after normalization.
        
        # Silhouette: [-1, 1] -> [0, 1]
        norm_sils = (np.array(raw_sils) + 1) / 2.0
        
        # Cohesion: lower is better. Normalize then invert.
        min_c, max_c = min(raw_cohesions), max(raw_cohesions)
        norm_cohesions = 1 - ((np.array(raw_cohesions) - min_c) / (max_c - min_c + 1e-9))
    
        # Separation: higher is better.
        min_s, max_s = min(raw_seps), max(raw_seps)
        norm_seps = (np.array(raw_seps) - min_s) / (max_s - min_s + 1e-9)
        
        # Davies-Bouldin: lower is better. Use inverse formula.
        norm_dbs = 1 / (1 + np.array(raw_dbs))
    
        # --- 4. Compute Final Weighted Score ---
        weights = {
            'silhouette': 0.2,
            'cohesion': 0.4,
            'separation': 0.3,
            'db': 0.1
        }
    
        quality_scores = (weights['silhouette'] * norm_sils +
                          weights['cohesion'] * norm_cohesions +
                          weights['separation'] * norm_seps +
                          weights['db'] * norm_dbs)
                          
        return {i: score for i, score in enumerate(quality_scores)}

    # -------------------- META-FEATURE ------------------
    def _compute_meta(self, X):
        """
        Restituisce distanze e pseudo-probabilità soft per ogni documento,
        garantendo dtype float64.
        """
        # 1) float64 sicuro
        X64 = X.astype(np.float64)

        # 2) Dense (float64) → predict
        dense = X64.toarray()
        labels = self.km.predict(dense)

        # 3) Centroidi in float64
        centroids = (
            self.km.cluster_centers_
            if self.km.cluster_centers_.dtype == np.float64
            else self.km.cluster_centers_.astype(np.float64)
        )

        dists, probs = [], []
        for vec, lab in zip(dense, labels):
            dist = np.linalg.norm(vec - centroids[lab])
            dists.append(dist)
            probs.append(1.0 / (1.0 + dist))

        return (
            np.asarray(dists, dtype=np.float64),
            np.asarray(probs, dtype=np.float64),
        )

    # -------------------- PHASE 7 -----------------------
    def _phase7_collect_examples(self):
        logging.info("Fase7: collect examples per cluster")
        cmap = defaultdict(list)
        total = count_nonempty_lines(self.file_path)
        pbar = tqdm(
            total=total, desc="collect-samples-per-cluster", unit="line"
        )
        for chunk in stream_log_file(self.file_path, self.chunk_size):
            Xb = transform_chunk(
                chunk,
                self.token2idx,
                self.idf,
                self.pool,
                self.n_procs,
                self.ng_cfg,
                self.sublinear_tf,
            )
            preds = self.km.predict(Xb)
            for ln, cl in zip(chunk, preds):
                if len(cmap[cl]) < self.samples_per_cluster:
                    cmap[cl].append(ln)
            pbar.update(len(chunk))
        pbar.close()
        return cmap

    # -------------------- PHASE 8 -----------------------

    # Modify your _phase8_print_examples function like this:
    def _phase8_print_examples(self, cmap):
        """
        Print examples per cluster, including the new unified Quality Score.
        """
        # Calculate the quality score for all clusters first
        quality_scores = self._calculate_cluster_quality()

        logging.info("Examples per cluster (sorted by Quality Score):")

        # Sort clusters by their quality score in descending order
        sorted_clusters = sorted(quality_scores.items(), key=lambda item: item[1], reverse=True)

        for cl, quality_score in sorted_clusters:
            ex = cmap.get(cl, [])
        #     Print the cluster header with its quality score
            print(f"\n[Cluster {cl}] ⇒ {len(ex)} esempi (Quality Score: {quality_score:.3f})")
            for ln in ex:
                print(f"  - {ln}")

    # -------------------- PHASE 9 -----------------------
    def _phase9_save(self):
        logging.info("Fase9: persisting models+metadata")

        # 1. Ottieni la directory di destinazione dalla configurazione.
        #    Se non specificata, usa la directory corrente ('.').
        model_dir = self.cfg.get("models_path", "models") # Esempio: 'models' come default
        
        # 2. Crea la directory se non esiste.
        #    os.makedirs crea tutte le directory intermedie necessarie.
        #    exist_ok=True evita errori se la cartella è già presente.
        os.makedirs(model_dir, exist_ok=True)
        logging.info(f"La directory dei modelli '{model_dir}' è pronta.")

        # 3. Costruisci i percorsi completi per ogni file usando os.path.join().
        #    Questo è il modo corretto e multipiattaforma per creare percorsi di file.
        km_path = os.path.join(model_dir, "km.joblib")
        rf_path = os.path.join(model_dir, "rf.joblib")
        meta_path = os.path.join(model_dir, "meta.npz")
        
        # 4. Salva i modelli e i metadati usando i nuovi percorsi.
        dump(self.km, km_path)
        logging.info(f"Modello K-Means salvato in: {km_path}")
        
        if self.clf:
            dump(self.clf, rf_path)
            logging.info(f"Modello RandomForest salvato in: {rf_path}")
            
        np.savez(
            meta_path,
            token2idx=self.token2idx,
            idf_array=self.idf,
            selected_mask=self.sel_mask,
        )
        logging.info(f"Metadati salvati in: {meta_path}")

    # -------------------- RUNTIME CLASSIFY --------------
    def classify_line(self, line: str) -> Tuple[str, int]:
        """
        Ritorna (method, label) dove method ∈ {'rf', 'cluster'}
        """
        rows, cols, data = worker_transform(
            (line, self.token2idx, self.idf, self.ng_cfg, self.sublinear_tf)
        )
        X = coo_matrix(
            (data, ([0] * len(cols), cols)),
            shape=(1, len(self.token2idx)),
            dtype=np.float64,  # float64 coerente
        ).tocsr()

        # Tentativo RF
        if self.clf is not None:
            dist, prob = self._compute_meta(X)
            meta = csr_matrix(np.column_stack((dist, prob)), dtype=np.float64)
            Xc = hstack([X, meta])
            Xs = Xc[:, self.sel_mask] if self.sel_mask is not None else Xc
            proba = self.clf.predict_proba(Xs)[0]
            if proba.max() >= self.conf_th:
                return "rf", int(self.clf.predict(Xs)[0])

        # Fallback k-means
        return "cluster", int(self.km.predict(X)[0])


# ------------------------------------------------
# Main
# ------------------------------------------------
def main():
    cfg = load_config(sys.argv[1] if len(sys.argv) > 1 else "config.yaml")
    mp = MultiPassFlow(cfg)
    mp.run()

    # quick test
    method, label = mp.classify_line(
        "Failed password root from 192.168.1.20"
    )
    print(f"[Main] method={method}, label={label}")


if __name__ == "__main__":
    main()
