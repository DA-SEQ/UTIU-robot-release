#!/usr/bin/env python3
"""
Unified multi-pass clustering and classification script.
Implements:
    - MultiPass clustering with MiniBatchKMeans
    - Two-tier classification with RandomForestClassifier fallback to KMeans
    - Meta-features (distance to centroid, softmax probability)
    - Feature selection for classifier
    - Cluster sample collection and display
    - Model persistence
"""

import sys
import os
import math
import yaml
import random
import numpy as np
import multiprocessing
from collections import defaultdict
from typing import List, Dict, Tuple
from tqdm import tqdm
from scipy.sparse import coo_matrix, csr_matrix, vstack, hstack
from sklearn.cluster import MiniBatchKMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import silhouette_score
from sklearn.feature_selection import chi2, SelectKBest
from joblib import dump, load

### --- Utility functions & Classes ---
def load_config(config_path: str) -> dict:
    if not os.path.exists(config_path):
        print(f"[Error] Configuration file '{config_path}' not found.")
        sys.exit(1)
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def stream_log_file(file_path: str, chunk_size: int = 50000):
    if not os.path.exists(file_path):
        print(f"[Error] File '{file_path}' not found.")
        sys.exit(1)
    lines = []
    count = 0
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            ln = line.strip()
            if ln:
                lines.append(ln)
                count += 1
                if count >= chunk_size:
                    yield lines
                    lines = []
                    count = 0
        if lines:
            yield lines

def count_nonempty_lines(file_path: str) -> int:
    c = 0
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            if line.strip():
                c += 1
    return c

def worker_transform_line_general(args):
    line, token2idx, idf_array, ngram_extractor = args
    tf_counter = defaultdict(int)
    ngrams = ngram_extractor(line)
    for ng in ngrams:
        cidx = token2idx.get(ng)
        if cidx is not None:
            tf_counter[cidx] += 1
    row_indices, col_indices, data_vals = [], [], []
    for col_idx, raw_tf in tf_counter.items():
        tf_sub = 1.0 + math.log(raw_tf)
        val = tf_sub * idf_array[col_idx]
        if val != 0.0:
            row_indices.append(0)
            col_indices.append(col_idx)
            data_vals.append(val)
    return (row_indices, col_indices, data_vals)

def transform_chunk_streaming_general(
    lines_chunk: List[str], 
    token2idx: Dict[str, int], 
    idf_array: np.ndarray, 
    ngram_extractor, 
    n_processes: int = 4
) -> csr_matrix:
    tasks = [(ln, token2idx, idf_array, ngram_extractor) for ln in lines_chunk]
    with multiprocessing.Pool(n_processes) as pool:
        results = list(pool.imap(worker_transform_line_general, tasks))
    rows_arr, cols_arr, data_arr = [], [], []
    for i, (r_idx, c_idx, dat) in enumerate(results):
        row_shifted = [i] * len(r_idx)
        rows_arr.extend(row_shifted)
        cols_arr.extend(c_idx)
        data_arr.extend(dat)
    coo_mat = coo_matrix(
        (data_arr, (rows_arr, cols_arr)),
        shape=(len(lines_chunk), len(token2idx)),
        dtype=np.float32
    )
    return coo_mat.tocsr()

def collect_word_ngrams_single_line(line: str) -> set:
    s = set()
    tokens = line.split()
    for t in tokens:
        s.add(t)
    for i in range(len(tokens) - 1):
        s.add(tokens[i] + " " + tokens[i+1])
    return s

def collect_char_ngrams_single_line(line: str) -> set:
    s = set()
    length = len(line)
    for n in range(3, 6):
        for start in range(length - n + 1):
            s.add(line[start:start + n])
    return s

def ngram_extractor_multipass(line: str):
    wset = collect_word_ngrams_single_line(line)
    cset = collect_char_ngrams_single_line(line)
    return wset | cset

def worker_docfreq_line(args):
    line, vocab_ = args
    out_dict = {}
    line_set = set()
    tokens = line.split()
    for t in tokens:
        if t in vocab_:
            line_set.add(t)
    for i in range(len(tokens) - 1):
        bigram = tokens[i] + " " + tokens[i+1]
        if bigram in vocab_:
            line_set.add(bigram)
    length = len(line)
    for n in range(3, 6):
        for start in range(length - n + 1):
            cng = line[start:start + n]
            if cng in vocab_:
                line_set.add(cng)
    for tok_ in line_set:
        out_dict[tok_] = 1
    return out_dict

def compute_doc_freq_streaming_multi_pass(
    file_path: str, vocab: Dict[str,int], chunk_size: int=50000, n_processes: int=4
) -> Dict[str, int]:
    df_global = defaultdict(int)
    total_lines = count_nonempty_lines(file_path)
    pbar = tqdm(total=total_lines, desc="doc-freq")
    lines_counted = 0
    for lines_chunk in stream_log_file(file_path, chunk_size):
        tasks = [(ln, vocab) for ln in lines_chunk]
        with multiprocessing.Pool(n_processes) as pool:
            partial_dicts = list(pool.imap(worker_docfreq_line, tasks))
        chunk_freq = defaultdict(int)
        for pd in partial_dicts:
            for tokn, val in pd.items():
                chunk_freq[tokn] += val
        for tk, vv in chunk_freq.items():
            df_global[tk] += vv
        lines_counted += len(lines_chunk)
        pbar.update(len(lines_chunk))
    pbar.close()
    print(f"[MultiPass] doc freq done. lines={lines_counted}, freq>0 tokens={len(df_global)}")
    return df_global

def build_vocabulary_streaming_multi_pass(
    file_path: str, chunk_size: int=50000, n_processes: int=4
) -> Dict[str,int]:
    global_set = set()
    total_lines = count_nonempty_lines(file_path)
    pbar = tqdm(total=total_lines, desc="vocab-building")
    lines_counted = 0
    for lines_chunk in stream_log_file(file_path, chunk_size):
        with multiprocessing.Pool(n_processes) as pool:
            partial_sets = list(pool.imap(ngram_extractor_multipass, lines_chunk))
        chunk_set = set()
        for s in partial_sets:
            chunk_set |= s
        global_set |= chunk_set
        lines_counted += len(lines_chunk)
        pbar.update(len(lines_chunk))
    pbar.close()
    vocab = {}
    idx = 0
    for tok in global_set:
        vocab[tok] = idx
        idx += 1
    print(f"[MultiPass] Finished vocab. size={len(vocab)}, lines={lines_counted}")
    return vocab

def build_full_tfidf_matrix_multi_pass(
    file_path: str,
    vocab: Dict[str,int],
    token2idx: Dict[str,int],
    idf_array: np.ndarray,
    chunk_size: int=50000,
    n_processes: int=4
) -> csr_matrix:
    blocks = []
    total_lines = count_nonempty_lines(file_path)
    pbar = tqdm(total=total_lines, desc="build-full-TFIDF")
    lines_counted = 0
    for lines_chunk in stream_log_file(file_path, chunk_size):
        X_chunk = transform_chunk_streaming_general(
            lines_chunk,
            token2idx=token2idx,
            idf_array=idf_array,
            ngram_extractor=ngram_extractor_multipass,
            n_processes=n_processes
        )
        blocks.append(X_chunk)
        lines_counted += len(lines_chunk)
        pbar.update(len(lines_chunk))
    pbar.close()
    if not blocks:
        return csr_matrix((0, len(token2idx)), dtype=np.float32)
    return vstack(blocks).tocsr()

def compute_meta_features(X_chunk: csr_matrix, model: MiniBatchKMeans):
    labels = model.predict(X_chunk)
    centroids = model.cluster_centers_
    distances = []
    probs = []
    for i, clust_id in enumerate(labels):
        c = centroids[clust_id]
        row_data = X_chunk.getrow(i).toarray().ravel()
        dist = np.linalg.norm(row_data - c)
        distances.append(dist)
        prob = 1.0/(1.0 + dist)
        probs.append(prob)
    return np.array(distances, dtype=np.float32), np.array(probs, dtype=np.float32)

def sample_cluster_lines(
    file_path: str,
    mbk: MiniBatchKMeans,
    token2idx: Dict[str, int],
    idf_array: np.ndarray,
    ngram_extractor,
    chunk_size: int = 20000,
    n_processes: int = 4,
    max_samples_per_cluster: int = 5
) -> Dict[int, List[str]]:
    cluster_samples = defaultdict(list)
    total_lines = count_nonempty_lines(file_path)
    pbar = tqdm(total=total_lines, desc="Collect-samples-per-cluster")
    for lines_chunk in stream_log_file(file_path, chunk_size):
        X_chunk = transform_chunk_streaming_general(
            lines_chunk,
            token2idx=token2idx,
            idf_array=idf_array,
            ngram_extractor=ngram_extractor,
            n_processes=n_processes
        )
        preds = mbk.predict(X_chunk)
        for i, line_text in enumerate(lines_chunk):
            clus_id = preds[i]
            if len(cluster_samples[clus_id]) < max_samples_per_cluster:
                cluster_samples[clus_id].append(line_text)
        pbar.update(len(lines_chunk))
    pbar.close()
    return cluster_samples

def print_cluster_samples(cluster_map: Dict[int, List[str]]):
    for clus_id, lines in cluster_map.items():
        print(f"[Cluster {clus_id}] => {len(lines)} sample lines collected:")
        for ln in lines:
            print(f"  {ln}")

### --- MultiPassFlow with Two-Tier Classifier ---

class MultiPassFlow:
    def __init__(self, config: dict):
        self.config = config
        self.file_path = config["file_path"]
        self.chunk_size = config.get("chunk_size", 20000)
        self.n_processes = config.get("n_processes", 4)
        kr = config.get("initial_k_range", [2,5])
        self.start_k = kr[0]
        self.end_k = kr[1]
        self.expand_k_if_best_is_max = config.get("expand_k_if_best_is_max", False)
        self.expand_step = config.get("expand_step", 5)
        self.max_expansions = config.get("max_expansions", 1)
        self.conf_threshold = config.get("confidence_threshold", 0.8)
        self.mp_kmeans_model_path = config.get("mp_kmeans_model_path", "mp_kmeans_model.joblib")
        self.mp_classifier_path = config.get("mp_classifier_path", "mp_classifier.joblib")
        self.mp_metadata_path = config.get("mp_metadata_path", "mp_metadata.npz")
        self.vocab = {}
        self.token2idx = {}
        self.idf_array = None
        self.best_k_overall = None
        self.mbk_final = None
        self.classifier = None
        self.selected_features_mask = None
        self.sample_buffer = []

    def run(self):
        print("[MultiPass] -> Starting multi-pass flow ...")
        self._phase1_vocab()
        self._phase2_docfreq_idf()
        self._phase3_build_full_tfidf_and_explore_k()
        self._phase4_final_partial_fit()
        self._gather_cluster_samples_for_classifier()
        self._train_classifier()
        self._save_multi_pass_model()
        print("\n[MultiPass] => Gathering cluster samples from file ...")
        cluster_map = sample_cluster_lines(
            file_path=self.file_path,
            mbk=self.mbk_final,
            token2idx=self.token2idx,
            idf_array=self.idf_array,
            ngram_extractor=ngram_extractor_multipass,
            chunk_size=self.chunk_size,
            n_processes=self.n_processes,
            max_samples_per_cluster=self.config.get("max_samples_per_cluster", 5)
        )
        print_cluster_samples(cluster_map)
        print("[MultiPass] -> flow complete.")

    def _phase1_vocab(self):
        self.vocab = build_vocabulary_streaming_multi_pass(
            self.file_path,
            chunk_size=self.chunk_size,
            n_processes=self.n_processes
        )
        self.token2idx = self.vocab

    def _phase2_docfreq_idf(self):
        df_global = compute_doc_freq_streaming_multi_pass(
            self.file_path,
            self.vocab,
            chunk_size=self.chunk_size,
            n_processes=self.n_processes
        )
        vocab_size = len(self.vocab)
        total_docs = count_nonempty_lines(self.file_path)
        self.idf_array = np.zeros(vocab_size, dtype=np.float32)
        for tok, i in self.token2idx.items():
            val = math.log(float(total_docs) / (1.0 + df_global.get(tok, 0))) + 1.0
            self.idf_array[i] = val

    def _phase3_build_full_tfidf_and_explore_k(self):
        X_full = build_full_tfidf_matrix_multi_pass(
            self.file_path,
            self.vocab,
            self.token2idx,
            self.idf_array,
            chunk_size=self.chunk_size,
            n_processes=self.n_processes
        )
        k_values = list(range(self.start_k, self.end_k + 1))
        best_sil = -1.0
        all_sil = []
        self.best_k_overall = None
        expansions_done = 0
        while True:
            for k_test in k_values:
                print(f"[MultiPass] => Testing k={k_test}")
                mbk = MiniBatchKMeans(
                    n_clusters=k_test,
                    init='k-means++',
                    batch_size=self.chunk_size,
                    random_state=42
                )
                try:
                    mbk.fit(X_full)
                    labels_full = mbk.predict(X_full)
                    inertia_val = mbk.inertia_
                    try:
                        sil_val = silhouette_score(X_full, labels_full)
                    except ValueError:
                        sil_val = -1
                    all_sil.append(sil_val)
                    print(f"  k={k_test}, inertia={inertia_val:.4f}, silhouette={sil_val:.4f}")
                    if sil_val > best_sil:
                        best_sil = sil_val
                        self.best_k_overall = k_test
                        self.mbk_final = mbk
                except Exception as e:
                    print(f"[MultiPass] WARNING: {e}")
                    continue
            if all(v == -1 for v in all_sil):
                print("[MultiPass] WARNING: silhouette failed for all k, picking the smallest k.")
                self.best_k_overall = min(k_values)
                self.mbk_final = MiniBatchKMeans(
                    n_clusters=self.best_k_overall,
                    init='k-means++',
                    batch_size=self.chunk_size,
                    random_state=42
                ).fit(X_full)
                break
            if self.expand_k_if_best_is_max and self.best_k_overall == self.end_k and expansions_done < self.max_expansions:
                self.end_k += self.expand_step
                k_values = list(range(self.start_k, self.end_k + 1))
                expansions_done += 1
                print(f"[MultiPass] best_k={self.best_k_overall} at end => expanding range to {self.start_k}..{self.end_k}")
            else:
                print(f"[MultiPass] => final chosen k={self.best_k_overall}, best_sil={best_sil:.4f}")
                break

    def _phase4_final_partial_fit(self):
        print(f"[MultiPass] => partial-fitting final K={self.best_k_overall}")
        total_lines = count_nonempty_lines(self.file_path)
        pbar = tqdm(total=total_lines, desc="final-partial-fit")
        for lines_chunk in stream_log_file(self.file_path, self.chunk_size):
            X_chunk = transform_chunk_streaming_general(
                lines_chunk,
                token2idx=self.token2idx,
                idf_array=self.idf_array,
                ngram_extractor=ngram_extractor_multipass,
                n_processes=self.n_processes
            )
            self.mbk_final.partial_fit(X_chunk)
            # Save for classifier sample buffer
            labels_chunk = self.mbk_final.predict(X_chunk)
            for i, ln in enumerate(lines_chunk):
                if random.random() < self.config.get("classifier_sample_rate", 0.01):
                    self.sample_buffer.append((ln, labels_chunk[i]))
            pbar.update(len(lines_chunk))
        pbar.close()

    def _gather_cluster_samples_for_classifier(self):
        # No-op: all samples already gathered in _phase4_final_partial_fit
        pass

    def _train_classifier(self):
        if not self.sample_buffer:
            print("[MultiPass] No samples for classifier. Skipping training.")
            return
        lines_list = [s[0] for s in self.sample_buffer]
        y_list = [s[1] for s in self.sample_buffer]
        X_tfidf = transform_chunk_streaming_general(
            lines_list,
            token2idx=self.token2idx,
            idf_array=self.idf_array,
            ngram_extractor=ngram_extractor_multipass,
            n_processes=self.n_processes
        )
        dist_arr, prob_arr = compute_meta_features(X_tfidf, self.mbk_final)
        meta_mat = np.column_stack((dist_arr, prob_arr))
        X_combined = hstack([X_tfidf, csr_matrix(meta_mat, dtype=np.float32)]).tocsr()
        max_feats = min(1000, X_combined.shape[1])
        selector = SelectKBest(chi2, k=max_feats)
        X_selected = selector.fit_transform(X_combined, y_list)
        self.selected_features_mask = selector.get_support()
        rf = RandomForestClassifier(**self.config.get("random_forest_params", {}))
        param_grid = {
            "n_estimators": [self.config.get("random_forest_params", {}).get("n_estimators", 50)],
            "max_depth": [self.config.get("random_forest_params", {}).get("max_depth", 10)]
        }
        cv = StratifiedKFold(n_splits=self.config.get("cv_folds", 3), shuffle=True, random_state=42)
        gs = GridSearchCV(rf, param_grid, cv=cv, verbose=1)
        gs.fit(X_selected, y_list)
        self.classifier = gs.best_estimator_
        print(f"[MultiPass] Best RF params: {gs.best_params_}, score={gs.best_score_:.4f}")

    # --- Two-Tier Classification ---
    def classify_line(self, line: str):
        X_tfidf, X_comb, X_selected = self._build_vectors_for_line(line)
        if not self.classifier:
            return ("fallback_cluster", self.mbk_final.predict(X_tfidf)[0])
        preds_proba = self.classifier.predict_proba(X_selected)
        max_conf = np.max(preds_proba)
        if max_conf >= self.conf_threshold:
            cl = self.classifier.predict(X_selected)[0]
            return ("rf", cl)
        cluster_label = self.mbk_final.predict(X_tfidf)[0]
        return ("fallback_cluster", cluster_label)
    
    def _build_vectors_for_line(self, line: str):
        ngrams = ngram_extractor_multipass(line)
        tf_counter = defaultdict(int)
        for ng in ngrams:
            cidx = self.token2idx.get(ng)
            if cidx is not None:
                tf_counter[cidx] += 1
        rows, cols, vals = [], [], []
        for c_, raw_tf in tf_counter.items():
            tf_sub = 1.0 + math.log(raw_tf)
            sc = tf_sub * self.idf_array[c_]
            if sc != 0.0:
                rows.append(0)
                cols.append(c_)
                vals.append(sc)
        X_tfidf = coo_matrix((vals, (rows, cols)), shape=(1, len(self.token2idx)), dtype=np.float32).tocsr()
        # For meta-features, need centroid and prob (using KMeans prediction)
        cluster_label = self.mbk_final.predict(X_tfidf)[0]
        centroid = self.mbk_final.cluster_centers_[cluster_label]
        row_data = X_tfidf.toarray().ravel()
        dist = np.linalg.norm(row_data - centroid)
        prob = 1.0/(1.0 + dist)
        meta_row = np.array([[dist, prob]], dtype=np.float32)
        X_comb = hstack([X_tfidf, csr_matrix(meta_row, dtype=np.float32)]).tocsr()
        X_selected = X_comb
        if self.selected_features_mask is not None:
            X_selected = X_selected[:, self.selected_features_mask]
        return X_tfidf, X_comb, X_selected


    def _predict_cluster(self, line: str):
        X_line = self._build_vector_for_line(line)
        return self.mbk_final.predict(X_line)[0]

    def _save_multi_pass_model(self):
        print("[MultiPass] Saving final kmeans + classifier + metadata ...")
        if self.mbk_final:
            dump(self.mbk_final, self.mp_kmeans_model_path)
        if self.classifier:
            dump(self.classifier, self.mp_classifier_path)
        np.savez(self.mp_metadata_path,
                 token2idx=self.token2idx,
                 idf_array=self.idf_array,
                 selected_features_mask=self.selected_features_mask)

#####################
def main():
    config_path = "config.yaml"
    if len(sys.argv) > 1:
        config_path = sys.argv[1]
    config = load_config(config_path)
    print("\n[Main] Configuration:")
    for k, v in config.items():
        print(f"  {k}: {v}")
    print("\n[Main] => MULTI-PASS MODE (TWO-TIER CLASSIFIER ENABLED)")
    mp = MultiPassFlow(config)
    mp.run()
    # Example classification
    test_line = "Failed password root from 192.168.1.20"
    method, label = mp.classify_line(test_line)
    print(f"[Main] Two-tier classification => method={method}, label={label}")

if __name__ == "__main__":
    main()

