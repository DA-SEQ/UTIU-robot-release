#!/usr/bin/env python3
"""
Anomaly detection in log files using Word2Vec and various clustering/unsupervised algorithms.
"""
import argparse
import json
import logging
import os
import nltk
# Auto-discover NLTK data in user home or via NLTK_DATA env var
data_home = os.getenv('NLTK_DATA', os.path.expanduser('~/nltk_data'))
if os.path.isdir(data_home):
    nltk.data.path.insert(0, data_home)
import re
import sys

import numpy as np
from gensim.models import Word2Vec
from nltk.tokenize import sent_tokenize, word_tokenize
from sklearn.cluster import KMeans
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.decomposition import PCA

try:
    import tqdm
except ImportError:
    tqdm = None


def parse_arguments():
    parser = argparse.ArgumentParser(description="Log anomaly detection using Word2Vec and clustering algorithms.")
    # I/O
    parser.add_argument('--input-file', '-i', required=True, help='Path to the log file to analyze')
    parser.add_argument('--output-file', '-o', help='Path to save anomalies (JSON or CSV by extension)')
    # Model
    parser.add_argument('--save-model', help='Path to save trained Word2Vec model')
    parser.add_argument('--load-model', help='Path to load existing Word2Vec model')
    # Hyperparameters
    parser.add_argument('--vector-size', type=int, default=100, help='Word2Vec vector dimensionality')
    parser.add_argument('--window', type=int, default=5, help='Word2Vec context window size')
    parser.add_argument('--min-count', type=int, default=1, help='Word2Vec minimum word count')
    parser.add_argument('--n-clusters', type=int, default=1, help='Number of clusters for KMeans')
    parser.add_argument('--std-dev-threshold', type=float, default=2.0, help='Std dev threshold for anomaly')
    parser.add_argument('--algorithm', choices=['kmeans', 'isolation_forest', 'lof'], default='kmeans',
                        help='Anomaly detection algorithm')
    parser.add_argument('--contamination', type=float, default=0.05,
                        help='Contamination for IsolationForest or LOF')
    parser.add_argument('--n-neighbors', type=int, default=20,
                        help='Number of neighbors for LOF')
    parser.add_argument('--config-file', help='Path to JSON config for regex patterns')
    parser.add_argument('--plot', action='store_true', help='Generate 2D PCA plot of vectors')
    parser.add_argument('--plot-file', default='anomaly_plot.png', help='Output path for plot')
    # Logging & verbosity
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    group.add_argument('--quiet', '-q', action='store_true', help='Suppress non-essential output')
    return parser.parse_args()


def configure_logging(verbose: bool, quiet: bool):
    level = logging.INFO
    if verbose:
        level = logging.DEBUG
    elif quiet:
        level = logging.ERROR
    logging.basicConfig(format='%(asctime)s %(levelname)s: %(message)s', level=level)


def load_config(path: str = None):
    default = {
        'ip_pattern': r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b',
        'date_pattern': r'^[A-Z][a-z]{2}\s{1,2}\d{1,2}\s\d{2}:\d{2}:\d{2}\s\w+\ssshd\[\d+\]:'
    }
    if not path:
        return default
    try:
        with open(path) as f:
            cfg = json.load(f)
        return {**default, **cfg}
    except FileNotFoundError:
        logging.warning(f"Config file not found: {path}. Using defaults.")
    except json.JSONDecodeError as e:
        logging.warning(f"Invalid JSON in config file '{path}': {e}. Using defaults.")
    return default


def check_nltk_data():
    try:
        _ = sent_tokenize("test sentence.")
    except LookupError:
        logging.error("NLTK punkt tokenizer not found. Please run: python3 -m nltk.downloader punkt")
        sys.exit(1)


def preprocess_logs(path: str, patterns: dict):
    if not os.path.exists(path):
        logging.error(f"Input file not found: {path}")
        sys.exit(1)
    try:
        with open(path) as f:
            lines = f.read().splitlines()
    except (IOError, OSError) as e:
        logging.error(f"Error reading file {path}: {e}")
        sys.exit(1)

    processed = []
    for line in (tqdm.tqdm(lines, desc="Preprocessing") if tqdm else lines):
        line = re.sub(patterns['ip_pattern'], 'ip_address', line)
        line = re.sub(patterns['date_pattern'], 'date_time', line)
        processed.append(line)
    return processed


def tokenize_sentences(lines: list):
    data = []
    for line in (tqdm.tqdm(lines, desc="Tokenizing") if tqdm else lines):
        for sent in sent_tokenize(line):
            tokens = [w.lower() for w in word_tokenize(sent)]
            data.append(tokens)
    if not data:
        logging.error("No valid sentences extracted. Exiting.")
        sys.exit(1)
    return data


def train_or_load_model(data, load_path, save_path, vector_size, window, min_count):
    if load_path and os.path.exists(load_path):
        logging.info(f"Loading Word2Vec model from {load_path}")
        return Word2Vec.load(load_path)
    logging.info("Training new Word2Vec model...")
    model = Word2Vec(data, vector_size=vector_size, window=window, min_count=min_count)
    if save_path:
        try:
            model.save(save_path)
            logging.info(f"Model saved to {save_path}")
        except (IOError, OSError) as e:
            logging.warning(f"Failed to save model: {e}")
    return model


def vectorize_sentences(data, model):
    vecs = []
    oov_count = 0
    total = len(data)
    for tokens in (tqdm.tqdm(data, desc="Vectorizing") if tqdm else data):
        word_vecs = [model.wv[w] for w in tokens if w in model.wv]
        if word_vecs:
            vec = np.mean(np.array(word_vecs), axis=0)
        else:
            vec = np.zeros(model.vector_size,)
            oov_count += 1
        vecs.append(vec)
    if oov_count > 0:
        if oov_count / total > 0.05:
            logging.warning(f"High OOV rate: {oov_count}/{total} sentences ({oov_count/total:.1%}) using zero vectors.")
        else:
            logging.info(f"Sentences with only OOV words: {oov_count}/{total}")
    return np.vstack(vecs)


def detect_anomalies(vectors, algorithm, **kwargs):
    if algorithm == 'kmeans':
        k = kwargs.get('n_clusters', 1)
        model = KMeans(n_clusters=k, random_state=0)
        model.fit(vectors)
        centers = model.cluster_centers_
        labels = model.labels_
        dists = np.linalg.norm(vectors - centers[labels], axis=1)
        anomalies = []
        for cluster_id in range(k):
            idxs = np.where(labels == cluster_id)[0]
            cluster_dists = dists[idxs]
            mean_k, std_k = cluster_dists.mean(), cluster_dists.std()
            thr_k = mean_k + kwargs.get('std_dev_threshold', 2.0) * std_k
            outliers = idxs[cluster_dists > thr_k]
            anomalies.extend(outliers.tolist())
        scores = dists
        anomalies = np.array(sorted(set(anomalies)))
    elif algorithm == 'isolation_forest':
        iso = IsolationForest(contamination=kwargs.get('contamination', 0.05))
        preds = iso.fit_predict(vectors)
        anomalies = np.where(preds < 0)[0]
        scores = -iso.score_samples(vectors)
    else:  # LOF
        lof = LocalOutlierFactor(n_neighbors=kwargs.get('n_neighbors', 20), contamination=kwargs.get('contamination', 0.05))
        preds = lof.fit_predict(vectors)
        anomalies = np.where(preds < 0)[0]
        scores = -lof.negative_outlier_factor_
    return anomalies, scores


def save_output(lines, data, anomalies, scores, path):
    import csv
    import json as _json
    records = []
    for idx in anomalies:
        records.append({
            'line': lines[idx],
            'tokens': data[idx],
            'score': float(scores[idx]),
            'index': int(idx)
        })
    if not records:
        logging.info("No anomalies detected; output file will not be created.")
        return
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext == '.csv':
            with open(path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=records[0].keys())
                writer.writeheader()
                writer.writerows(records)
        else:
            with open(path, 'w') as f:
                _json.dump(records, f, indent=2)
        logging.info(f"Anomalies saved to {path}")
    except (IOError, OSError) as e:
        logging.error(f"Failed to write output: {e}")


def visualize(vectors, anomalies, plot_file):
    try:
        pca = PCA(n_components=2)
        proj = pca.fit_transform(vectors)
        import matplotlib.pyplot as plt
        plt.figure()
        plt.scatter(proj[:, 0], proj[:, 1], s=10, label='Normal')
        plt.scatter(proj[anomalies, 0], proj[anomalies, 1], s=30, label='Anomaly')
        plt.legend()
        plt.title('Log Sentence Embeddings')
        plt.savefig(plot_file)
        logging.info(f"Plot saved to {plot_file}")
    except Exception as e:
        logging.warning(f"Visualization failed: {e}")


def main():
    args = parse_arguments()
    configure_logging(args.verbose, args.quiet)
    check_nltk_data()  # Early NLTK check

    if args.plot:
        # Validate plotting dependencies
        try:
            import matplotlib  # noqa
            from sklearn.decomposition import PCA  # noqa
        except ImportError as e:
            logging.error(f"Plotting requested but dependencies are missing: {e}")
            sys.exit(1)

    patterns = load_config(args.config_file)

    lines = preprocess_logs(args.input_file, patterns)
    data = tokenize_sentences(lines)
    model = train_or_load_model(data, args.load_model, args.save_model,
                                args.vector_size, args.window, args.min_count)
    vecs = vectorize_sentences(data, model)
    anomalies, scores = detect_anomalies(
        vecs,
        args.algorithm,
        n_clusters=args.n_clusters,
        std_dev_threshold=args.std_dev_threshold,
        contamination=args.contamination,
        n_neighbors=args.n_neighbors
    )

    # Conditional console output
    if args.output_file is None:
        for idx in anomalies:
            logging.info(f"Anomaly @{idx}: {lines[idx]} | Score: {scores[idx]}")
        logging.info(f"Total anomalies: {len(anomalies)}")

    if args.output_file:
        save_output(lines, data, anomalies, scores, args.output_file)
    if args.plot:
        visualize(vecs, anomalies, args.plot_file)


if __name__ == '__main__':
    main()

