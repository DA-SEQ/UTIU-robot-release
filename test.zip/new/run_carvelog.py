#!/usr/bin/env python3
"""
cluster_live.py
────────────────────────────────────────────────────────────────────────────
Esegue la clusterizzazione (o classificazione RF) di un nuovo corpus usando
i modelli addestrati da carvelog.py e mostra l'andamento in tempo reale.

Richiede:
  • un file YAML di configurazione (vedi esempio più sotto)
  • i file salvati da carvelog.py:
        - km.joblib                 → modello MiniBatchKMeans
        - rf.joblib   (opzionale)   → modello RandomForestClassifier
        - meta.npz                 → token2idx, idf_array, selected_mask

Esempio di config.yaml:

    file_path: "nuovi_log.txt"          # log da processare
    chunk_size: 50000                   # righe per batch
    models_dir: "./models"              # dove sono km.joblib, rf.joblib, meta.npz
    show_examples_per_cluster: 3        # facoltativo, stampa esempi a fine run

────────────────────────────────────────────────────────────────────────────
"""

import os
import sys
import yaml
import math
import logging
import numpy as np
from collections import Counter, defaultdict
from typing import List, Dict, Tuple

from tqdm import tqdm
from joblib import load as joblib_load
from scipy.sparse import coo_matrix, csr_matrix, hstack
from sklearn.exceptions import NotFittedError

# ------------------------------------------------------------------ logging
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# ------------------------------------------------------------------ helpers
def load_config(path: str) -> dict:
    if not os.path.exists(path):
        logging.error(f"Config file '{path}' not found.")
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def stream_file(file_path: str, chunk_size: int):
    """Yield list<str> of *chunk_size* non-empty lines."""
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        buf = []
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            buf.append(ln)
            if len(buf) >= chunk_size:
                yield buf
                buf = []
        if buf:
            yield buf


def count_nonempty_lines(file_path: str) -> int:
    cnt = 0
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        for ln in f:
            if ln.strip():
                cnt += 1
    return cnt


# -------------------- N-grams (deve riflettere training) -------------------
def collect_word_ngrams(line: str) -> set:
    toks = line.split()
    s = set(toks)
    s |= {f"{toks[i]} {toks[i+1]}" for i in range(len(toks) - 1)}
    return s


def collect_char_ngrams(line: str) -> set:
    s = set()
    L = len(line)
    for n in range(3, 6):
        for i in range(L - n + 1):
            s.add(line[i : i + n])
    return s


def ngram_extractor(line: str) -> set:
    """Stessa logica usata in training."""
    return collect_word_ngrams(line) | collect_char_ngrams(line)


# -------------------- TF-IDF transform ------------------------------------
def worker_transform(args):
    line, token2idx, idf = args
    tf = defaultdict(int)

    for ng in ngram_extractor(line):
        idx = token2idx.get(ng)
        if idx is not None:
            tf[idx] += 1

    rows, cols, data = [], [], []
    for idx_, cnt in tf.items():
        val = (1 + math.log(cnt)) * idf[idx_]
        if val != 0:
            rows.append(0)
            cols.append(idx_)
            data.append(val)

    return rows, cols, data


def tfidf_chunk(
    lines: List[str], token2idx: Dict[str, int], idf: np.ndarray
) -> csr_matrix:
    rows, cols, data = [], [], []
    for i, ln in enumerate(lines):
        r, c, d = worker_transform((ln, token2idx, idf))
        rows.extend([i] * len(r))
        cols.extend(c)
        data.extend(d)

    return coo_matrix(
        (data, (rows, cols)),
        shape=(len(lines), len(token2idx)),
        dtype=np.float64,
    ).tocsr()


# -------------------- LiveClustering class --------------------------------
class LiveClustering:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._load_models(cfg)

    # ........................................................... load
    def _load_models(self, cfg: dict):
        mdl_dir = cfg.get("models_dir", ".")
        km_path = os.path.join(mdl_dir, cfg.get("kmeans_file", "km.joblib"))
        rf_path = os.path.join(mdl_dir, cfg.get("rf_file", "rf.joblib"))
        meta_path = os.path.join(mdl_dir, cfg.get("meta_file", "meta.npz"))

        if not os.path.exists(km_path):
            logging.error(f"KMeans model not found: {km_path}")
            sys.exit(1)
        if not os.path.exists(meta_path):
            logging.error(f"Metadata file not found: {meta_path}")
            sys.exit(1)

        logging.info("Caricamento modelli…")
        self.km = joblib_load(km_path)

        self.clf = None
        if os.path.exists(rf_path):
            try:
                self.clf = joblib_load(rf_path)
            except Exception as e:
                logging.warning(f"RF not loaded ({e!s}). Fallback a k-means.")

        meta = np.load(meta_path, allow_pickle=True)
        self.token2idx = meta["token2idx"].item()
        self.idf_array = meta["idf_array"].astype(np.float64)
        self.sel_mask = (
            meta["selected_mask"] if "selected_mask" in meta.files else None
        )

        self.conf_th = cfg.get("confidence_threshold", 0.8)

        logging.info(
            f"Modelli caricati. Vocab size={len(self.token2idx)}, "
            f"clusters={self.km.n_clusters}, RF={'yes' if self.clf else 'no'}"
        )

    # ........................................................... meta
    def _meta_features(self, X_csr: csr_matrix):
        dense = X_csr.astype(np.float64).toarray()
        labels = self.km.predict(dense)
        cents = self.km.cluster_centers_.astype(np.float64, copy=False)

        dists = np.linalg.norm(dense - cents[labels], axis=1)
        probs = 1.0 / (1.0 + dists)
        return dists.reshape(-1, 1), probs.reshape(-1, 1)

    # ........................................................... classify
    def _classify_batch(self, X: csr_matrix):
        """Restituisce np.ndarray con etichette finali."""
        if self.clf is None:
            return self.km.predict(X.astype(np.float64))

        d, p = self._meta_features(X)
        meta = csr_matrix(np.hstack([d, p]), dtype=np.float64)
        Xc = hstack([X.astype(np.float64), meta])

        if self.sel_mask is not None and self.sel_mask.any():
            Xc = Xc[:, self.sel_mask]

        try:
            proba = self.clf.predict_proba(Xc)
            confident = proba.max(axis=1) >= self.conf_th
            labels_rf = self.clf.predict(Xc)

            labels_km = self.km.predict(X.astype(np.float64))
            return np.where(confident, labels_rf, labels_km)
        except (NotFittedError, AttributeError):
            logging.warning("RF not usable → fallback k-means.")
            return self.km.predict(X.astype(np.float64))

    # ........................................................... run
    def run(self):
        infile = self.cfg["file_path"]
        if not os.path.exists(infile):
            logging.error(f"Input file '{infile}' not found.")
            sys.exit(1)

        total = count_nonempty_lines(infile)
        chunk_size = self.cfg.get("chunk_size", 50000)
        show_examples = self.cfg.get("show_examples_per_cluster", 0)

        cluster_counter = Counter()
        examples = defaultdict(list)

        pbar = tqdm(total=total, desc="Clustering", unit="line")

        for chunk in stream_file(infile, chunk_size):
            X = tfidf_chunk(chunk, self.token2idx, self.idf_array)
            labels = self._classify_batch(X)

            # ­ update statistics
            cluster_counter.update(labels)

            if show_examples:
                for ln, lab in zip(chunk, labels):
                    if len(examples[lab]) < show_examples:
                        examples[lab].append(ln)

            # ­ update status bar
            most_common = cluster_counter.most_common(5)
            postfix = {f"C{cl}": cnt for cl, cnt in most_common}
            pbar.update(len(chunk))
            pbar.set_postfix(postfix)

        pbar.close()

        # --- summary ---
        print("\n=== Distribuzione finale ===")
        for cl, cnt in sorted(cluster_counter.items()):
            print(f"Cluster {cl:>3}: {cnt}")

        if show_examples:
            print("\n=== Esempi per cluster ===")
            for cl in sorted(examples):
                print(f"\n[Cluster {cl}]")
                for ln in examples[cl]:
                    print(f"  - {ln}")


# ------------------------------------------------------------------ main
def main():
    cfg_path = sys.argv[1] if len(sys.argv) > 1 else "config_cluster.yaml"
    cfg = load_config(cfg_path)

    lc = LiveClustering(cfg)
    lc.run()


if __name__ == "__main__":
    main()

