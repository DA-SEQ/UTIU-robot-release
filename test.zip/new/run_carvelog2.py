#!/usr/bin/env python3
"""
cluster_rf_only.py
────────────────────────────────────────────────────────────────────────────
Classifica un corpus di log sfruttando esclusivamente la Random-Forest
addestrata da carvelog.py.

Requisiti nella directory models_dir (config):
    • rf.joblib      modello RandomForestClassifier     ← OBLIGATORIO
    • km.joblib      modello MiniBatchKMeans            ← per meta-feature
    • meta.npz       token2idx, idf_array, selected_mask

Config YAML minimo (es. config_rf.yaml):

    file_path: "nuovi_log.txt"
    models_dir: "./models"
    chunk_size: 50000
    show_examples_per_cluster: 3     # facoltativo
    log_level: "INFO"                # DEBUG / INFO / WARNING

Uso:
    python3 cluster_rf_only.py config_rf.yaml
"""

import os, sys, yaml, math, logging
import numpy as np
from collections import Counter, defaultdict
from typing import List, Dict
from tqdm import tqdm
from joblib import load as joblib_load
from scipy.sparse import coo_matrix, csr_matrix, hstack

# ──────────────────── logging & cfg
def load_cfg(path: str) -> dict:
    if not os.path.exists(path):
        print(f"[FATAL] config '{path}' non trovato", file=sys.stderr)
        sys.exit(1)
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def init_log(level: str):
    logging.basicConfig(
        level=getattr(logging, level.upper(), logging.INFO),
        format="[%(asctime)s] %(levelname)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

# ──────────────────── file helpers
def count_lines(fp: str) -> int:
    c = 0
    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
        for ln in f:
            if ln.strip():
                c += 1
    return c

def stream(fp: str, chunk: int):
    buf = []
    with open(fp, "r", encoding="utf-8", errors="ignore") as f:
        for ln in f:
            ln = ln.rstrip("\n")
            if not ln:
                continue
            buf.append(ln)
            if len(buf) >= chunk:
                yield buf
                buf = []
        if buf:
            yield buf

# ──────────────────── n-grams (identici al training)
def w_ngrams(l: str) -> set:
    t = l.split()
    s = set(t)
    s |= {f"{t[i]} {t[i+1]}" for i in range(len(t) - 1)}
    return s

def c_ngrams(l: str) -> set:
    s, L = set(), len(l)
    for n in range(3, 6):
        for i in range(L - n + 1):
            s.add(l[i : i + n])
    return s

def ngrams(line: str) -> set:
    return w_ngrams(line) | c_ngrams(line)

# ──────────────────── TF-IDF rapido (seriale)
def tfidf(lines: List[str], tok2id: Dict[str, int], idf: np.ndarray):
    r, c, d = [], [], []
    for i, ln in enumerate(lines):
        tf = {}
        for ng in ngrams(ln):
            idx = tok2id.get(ng)
            if idx is not None:
                tf[idx] = tf.get(idx, 0) + 1
        for idx, cnt in tf.items():
            r.append(i)
            c.append(idx)
            d.append((1 + math.log(cnt)) * idf[idx])
    return coo_matrix((d, (r, c)),
                      shape=(len(lines), len(tok2id)),
                      dtype=np.float64).tocsr()

# ──────────────────── main class
class RFOnly:
    def __init__(self, cfg: dict):
        self.cfg = cfg
        self._load_models()

        self.cluster_counter = Counter()
        self.examples = defaultdict(list)

    # ---------- load
    def _load_models(self):
        d = self.cfg.get("models_dir", ".")
        rf_path = os.path.join(d, "rf.joblib")
        km_path = os.path.join(d, "km.joblib")
        meta_npz = os.path.join(d, "meta.npz")

        if not os.path.exists(rf_path):
            logging.critical("Random-Forest (rf.joblib) mancante: impossibile procedere.")
            sys.exit(1)
        if not os.path.exists(km_path):
            logging.critical("KMeans (km.joblib) mancante: serve per meta-feature.")
            sys.exit(1)
        if not os.path.exists(meta_npz):
            logging.critical("Metadata meta.npz mancante.")
            sys.exit(1)

        logging.info("Caricamento Random-Forest…")
        self.clf = joblib_load(rf_path)

        logging.info("Caricamento KMeans (solo per meta-feature)…")
        self.km = joblib_load(km_path)

        meta = np.load(meta_npz, allow_pickle=True)
        self.tok2id: Dict[str, int] = meta["token2idx"].item()
        self.idf = meta["idf_array"].astype(np.float64)
        self.sel_mask = meta["selected_mask"] if "selected_mask" in meta else None

        self.idx2tok = {i: t for t, i in self.tok2id.items()}

        logging.info(f"Vocab size={len(self.tok2id):,}, clusters={self.km.n_clusters}")
        if self.sel_mask is not None:
            logging.info(f"RF usa {int(self.sel_mask.sum())} feature selezionate.")

    # ---------- meta-feature
    def _meta(self, X):
        dense = X.astype(np.float64).toarray()
        labs = self.km.predict(dense)
        cents = self.km.cluster_centers_.astype(np.float64, copy=False)
        dists = np.linalg.norm(dense - cents[labs], axis=1)
        probs = 1.0 / (1.0 + dists)
        return dists.reshape(-1, 1), probs.reshape(-1, 1)

    # ---------- batch classify (solo RF)
    def classify_batch(self, X):
        d, p = self._meta(X)
        meta = csr_matrix(np.hstack([d, p]), dtype=np.float64)
        Xc = hstack([X.astype(np.float64), meta])
        if self.sel_mask is not None and self.sel_mask.any():
            Xc = Xc[:, self.sel_mask]
        return self.clf.predict(Xc)

    # ---------- helper top token
    def _top_tok(self, cl, k=5):
        vec = self.km.cluster_centers_[cl]
        idx = np.argpartition(-vec, range(k))[:k]
        idx = idx[np.argsort(-vec[idx])]
        return ", ".join(self.idx2tok[i] for i in idx)

    # ---------- run
    def run(self):
        path = self.cfg["file_path"]
        if not os.path.exists(path):
            logging.critical(f"File input '{path}' non trovato.")
            sys.exit(1)

        tot = count_lines(path)
        chunk = self.cfg.get("chunk_size", 50000)
        show = self.cfg.get("show_examples_per_cluster", 0)

        bar = tqdm(total=tot, desc="RF classifying", unit="line")
        for part in stream(path, chunk):
            X = tfidf(part, self.tok2id, self.idf)
            labs = self.classify_batch(X)

            self.cluster_counter.update(labs)
            if show:
                for ln, lab in zip(part, labs):
                    if len(self.examples[lab]) < show:
                        self.examples[lab].append(ln)

            common = self.cluster_counter.most_common(3)
            bar.set_postfix({f"C{c}": n for c, n in common})
            bar.update(len(part))
        bar.close()

        # ---- report finale
        print("\n=== Distribuzione cluster (RF) ===")
        for cl in sorted(self.cluster_counter):
            n = self.cluster_counter[cl]
            print(f"[C{cl:>3}] {n:>8} righe   top-token: {self._top_tok(cl)}")

        if show:
            print(f"\n=== Esempi (max {show} per cluster) ===")
            for cl in sorted(self.examples):
                print(f"\n[C{cl}]")
                for ln in self.examples[cl]:
                    print("  •", ln)

# ──────────────────── main
def main():
    cfg_file = sys.argv[1] if len(sys.argv) > 1 else "config_rf.yaml"
    cfg = load_cfg(cfg_file)
    init_log(cfg.get("log_level", "INFO"))

    runner = RFOnly(cfg)
    runner.run()

if __name__ == "__main__":
    main()

